from django.db import models
from datetime import datetime
from django.utils import timezone
from django.contrib.auth.models import AbstractUser,PermissionsMixin, BaseUserManager, AbstractBaseUser
from django.contrib.admin.models import ContentType
from django.utils.translation import ugettext_lazy as _
from django.core.validators import RegexValidator
from model_utils import Choices
from django.utils.timezone import now

class UserManager(BaseUserManager):
	"""Define a model manager for User model with no username field."""

	"""A custom user manager to deal with emails as unique identifiers for authi
	nstead of usernames. The default that's used is "UserManager"
	"""
	
	def _create_user(self, email, password, **extra_fields):
		#"""Creates and saves a User with the given email and password."""
		
		if not email:
			raise ValueError('The Email must be set')
		email = self.normalize_email(email)
		user = self.model(email=email, **extra_fields)
		user.set_password(password)
		user.save()
		return user

	def create_superuser(self, email, password, **extra_fields):
		"""Create and save a SuperUser with the given email and password."""
		extra_fields.setdefault('is_staff', True)
		extra_fields.setdefault('is_superuser', True)

		if extra_fields.get('is_staff') is not True:
		    raise ValueError('Superuser must have is_staff=True.')
		if extra_fields.get('is_superuser') is not True:
		    raise ValueError('Superuser must have is_superuser=True.')

		return self._create_user(email, password, **extra_fields)

class User(AbstractBaseUser):
    frist_name=models.CharField(max_length=255,null=True)
    last_name=models.CharField(max_length=255,null=True)
    GENDER_CHOICES = (
        ('M', 'Male'),
        ('F', 'Female'),
    )
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    mobile = models.CharField(max_length=15, blank=True)
    email = models.EmailField(unique=True, null=True)
    
    is_staff = models.BooleanField(
	    _('staff status'),
	    default=False,
	    help_text=_('Designates whether the user can log into this site.'),
	)
    is_active = models.BooleanField(
	    _('active'),
	    default=True,
	    help_text=_(
	        'Designates whether this user should be treated as active. '
	        'Unselect this instead of deleting accounts.'
	    ),
	)
    USERNAME_FIELD = 'email'
    objects = UserManager()

    def __str__(self):
	    return self.email

    def get_full_name(self):
	    return self.email

    def get_short_name(self):
	    return self.email

class AccountsUser(models.Model):
    frist_name=models.CharField(max_length=255,null=True)
    last_name=models.CharField(max_length=255,null=True)
    GENDER_CHOICES = (
        ('M', 'Male'),
        ('F', 'Female'),
    )
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    mobile = models.CharField(max_length=15, blank=True)
    email = models.EmailField(unique=True, null=True)
    class Meta:
        managed = False
        db_table = 'accounts_user'
    def __str__(self):
        return self.full_name

    def get_full_name(self):
        return self.name

    def get_short_name(self):
        return self.name 


class City(models.Model):
    """
    A Model representing a the project.
    """
    Name = models.CharField(max_length=35)
    CountryCode = models.CharField(max_length=3)
    District = models.CharField(max_length=20)
    Population=models.IntegerField(default=11)
    class Meta:
    	managed = False
    	db_table = 'city'

class Country(models.Model):
    """
    A Model representing a the project.
    """
    #Code = models.CharField(max_length=3)
    Code=models.ForeignKey(City, models.DO_NOTHING, db_column='Code')
    Name = models.CharField(max_length=52)
    STATUS = Choices('Asia','Europe','North America','Africa','Oceania','Antarctica','South America')
    Continent = models.CharField(choices=STATUS,max_length=100,default='Asia')	
    Region = models.CharField(max_length=26)
    SurfaceArea=models.FloatField(null=True, blank=True,default=0.00)
    IndepYear=models.IntegerField(default=6)
    Population=models.IntegerField(default=11)
    LifeExpectancy=models.FloatField(null=True, blank=True,default=0.00)
    GNP=models.FloatField(null=True, blank=True,default=0.00)
    GNPOld=models.FloatField(null=True, blank=True,default=0.00)
    LocalName=models.CharField(max_length=45)
    GovernmentForm=models.CharField(max_length=45)
    HeadOfState=models.CharField(max_length=60)
    Capital=models.IntegerField(default=11)
    Code2=models.CharField(max_length=2)
    class Meta:
    	managed = False
    	db_table = 'country'

class Countrylanguage(models.Model):
    """
    A Model representing a the project.
    """
    #Name = models.CharField(max_length=200)
    #CountryCode = models.CharField(max_length=30)
    CountryCode=models.ForeignKey(City, models.DO_NOTHING, db_column='CountryCode')
    Language = models.CharField(max_length=30)
    STATUS = Choices('T','F')
    IsOfficial=models.CharField(choices=STATUS,max_length=2,default='F')
    Percentage=models.FloatField(null=True, blank=True,default=0.00)
    class Meta:
    	managed = False
    	db_table = 'countrylanguage'


class EmailOTP(models.Model):
    email = models.EmailField(unique=True, null=True)
    otp=models.CharField(max_length=6,null=True)
    otp_sent_time=models.DateTimeField(default=now, blank=True)

    class Meta:
        managed = False
        db_table = 'email_otp'


# class UserManager(BaseUserManager):
#     def _create_user(self, phone_number,password,is_staff=False,is_admin=False,is_active=True, **extra_fields):
#         if not phone_number:
#             raise ValueError('User must have phone number')
#         if not password:
#             raise ValueError('User must have password')

#         user_obj=self.model(
#             phone_number=phone_number

#             )
#         user_obj.set_password(password)
#         user_obj.staff=is_staff
#         user_obj.admin=is_admin
#         user_obj.active=is_active
#         user_obj.save(using=self._db)
#         return user_obj

#     def create_staffuser(self, phone_number, password=None):
#         user=self._create_user(phone_number,
#             password=password,
#             is_staff=True,
#             )
#         return user

#     def create_superuser(self, phone_number, password=None):
#         user=self._create_user(phone_number,
#             password=password,
#             is_staff=True,
#             is_admin=True,
#             is_superuser=True
#         )
        
#         return user

    
# class User(AbstractBaseUser,PermissionsMixin):
#     first_name=models.CharField(max_length=255,null=True)
#     last_name=models.CharField(max_length=255,null=True)
#     GENDER_CHOICES = (
#         ('M', 'Male'),
#         ('F', 'Female'),
#     )
#     gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
#     email = models.EmailField(unique=True, null=True)
#     phone_regex = RegexValidator(regex=r'(\+91)\d{10}$', message="Phone number must be entered in the format: '+919999999'. Up to 13 digits allowed.")
#     phone_number = models.CharField(validators=[phone_regex], max_length=15, unique=True) # validators should be a list
#     otp=models.CharField(max_length=6,null=True)
#     is_staff = models.BooleanField(default=False)
#     is_active = models.BooleanField(default=True)
#     is_admin=models.BooleanField(default=False)
#     timestamp=models.DateTimeField(auto_now_add=True)

#     USERNAME_FIELD = 'phone_number'
#     objects = UserManager()

#     def __str__(self):
#         return self.email

#     def get_full_name(self):
#         return self.email

#     def get_short_last_name(self):
#         return self.email
#     @property
#     def is_istaff(self):
#         return self.istaff
#     @property
#     def is_isadmin(self):
#         return self.istaff
#     @property
#     def is_isactive(self):
#         return self.istaff

    

# class AccountsUser(models.Model):
#     first_name=models.CharField(max_length=255,null=True)
#     last_name=models.CharField(max_length=255,null=True)
#     GENDER_CHOICES = (
#         ('M', 'Male'),
#         ('F', 'Female'),
#     )
#     gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
#     email = models.EmailField(unique=True, null=True)
#     phone_regex = RegexValidator(regex=r'(\+91)\d{10}$', message="Phone number must be entered in the format: '+919999999'. Up to 13 digits allowed.")
#     phone_number = models.CharField(validators=[phone_regex], max_length=15, unique=True) # validators should be a list
#     otp=models.CharField(max_length=6,null=True)
#     is_staff = models.BooleanField(default=False)
#     is_active = models.BooleanField(default=True)
#     is_admin=models.BooleanField(default=False)
#     timestamp=models.DateTimeField(auto_now_add=True)
    
    
#     class Meta:
#         managed = False
#         db_table = 'accounts_user'
#     def __str__(self):
#         return self.email

#     def get_full_name(self):
#         return self.email

#     def get_short_last_name(self):
#         return self.email
#     @property
#     def is_istaff(self):
#         return self.istaff
#     @property
#     def is_isadmin(self):
#         return self.istaff
#     @property
#     def is_isactive(self):
#         return self.istaff
# class EmailOTP(models.Model):
#     email = models.EmailField(unique=True, null=True)
#     otp=models.CharField(max_length=6,null=True)
#     otp_sent_time=models.DateTimeField(default=now, blank=True)

#     class Meta:
#         managed = False
#         db_table = 'email_otp'



# class City(models.Model):
#     """
#     A Model representing a the project.
#     """
#     Name = models.CharField(max_length=200)
#     CountryCode = models.CharField(max_length=11)
#     District = models.CharField(max_length=200)
#     Population=models.IntegerField(default=11)
#     class Meta:
#         managed = False
#         db_table = 'city'

