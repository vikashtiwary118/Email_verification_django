from django.contrib import admin

# # Register your models here.
# from django.contrib import admin
# #from _future_ import unicode_literals
# from django.contrib.auth import get_user_model
# #User=get_user_model()
# from django.contrib.auth.models import Group
# #from django.contrib.auth.admin import UserAdmin
# from .models import User
# from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
# from .forms import UserAdminCreationForm,  UserAdminChangeForm


# class MyUserAdmin(BaseUserAdmin):
# 	form=UserAdminChangeForm
# 	add_form=UserAdminCreationForm

# 	list_display=('first_name','last_name','gender','email','phone_number')
# 	list_filter=('is_staff','is_active','is_admin')

# 	fieldsets = (
#         (None, {'fields': ('phone_number', 'password')}),
#         ('Personal info', {'fields': ('first_name', 'last_name')}),
#         ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
#         ('Important dates', {'fields': ('last_login', 'date_joined')}),
#         ('Contact info', {'fields': ('email',)}),)
# 	add_fieldsets = (
#         (None, {
#             'classes': ('wide',),
#             'fields': ('email', 'password1', 'password2'),}),)
	


# 	search_fields=('phone_number','first_name','last_name')
# 	ordering=('phone_number','first_name','last_name')
# 	filter_horizontal=()

# 	def get_inline_instance(self, request,obj=None):
# 		if not obj:
# 			return list()
# 		return super(UserAdmin, self).get_inline_instance(request,obj)

# admin.site.register(User , MyUserAdmin)

