from .models import User
from django.db.models import Q
from django.core.exceptions import ValidationError
from django import forms
from django.contrib.auth import password_validation

class UserForm(forms.ModelForm):
	error_css_class = 'alert alert-danger'
	first_name=forms.CharField(widget=forms.TextInput(attrs={'class':"form-control"}))
	last_name=forms.CharField(widget=forms.TextInput(attrs={'class':"form-control"}))
	mobile=forms.RegexField(initial='+91',regex=r'(\+91)\d{10}$',widget=forms.TextInput(attrs={'class':"form-control","placeholder":"Mobile no"}))
	email=forms.EmailField(widget=forms.TextInput(attrs={'class':"form-control"}))
	password=forms.CharField(widget=forms.PasswordInput(attrs={'class':"form-control"}),help_text=password_validation.password_validators_help_text_html())
	confirm_password=forms.CharField(widget=forms.PasswordInput(attrs={'class':"form-control"}))

	class Meta:
		model=User
		fields=['frist_name','last_name','mobile','email','password']
	 
	def _post_clean(self):
		super()._post_clean()
		# Validate the password after self.instance is updated with form data
		# by super().
		password = self.cleaned_data.get('password')
		if password:
			try:
				password_validation.validate_password(password, self.instance)
			except forms.ValidationError as error:
				self.add_error('password', error)

	def clean(self):
		cleaned_data = super(UserForm, self).clean()
		password = cleaned_data.get("password")
		confirm_password = cleaned_data.get("confirm_password")
        
		if password != confirm_password:
			raise forms.ValidationError("password and confirm_password does not match")
