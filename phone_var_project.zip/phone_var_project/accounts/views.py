# accounts/views.py
from .forms import UserForm
from django.urls import reverse_lazy
from django.views import generic
from django.shortcuts import render, redirect
from django.shortcuts import render_to_response
from django.template import RequestContext
from .models import User,Country,City
# class SignUp(generic.CreateView):
#     form_class = UserForm
#     success_url = reverse_lazy('login')
#     template_name = 'accounts/signup.html'

# def SignUp(request, template_name='accounts/signup.html'):
#     form = UserForm(request.POST or None)
#     if form.is_valid():
#         form.save()
#         return redirect('login')
#     return render(request, template_name, {'form':form})

from django.http import HttpResponse

#,Country__Name__contains='k',Countrylanguage__Name__contains='k'
def dashboard(request):
    #search_data=City.objects.filter(Name__contains='k').select_related('Country').select_related('Countrylanguage')
    search_data=City.objects.filter(Name__contains='k')
    print(search_data)
    exit()
    #return 


class SignUp(generic.CreateView):
    form_class = UserForm
    template_name = 'accounts/signup.html'
  
    def get(self,request):
        if request.user.is_authenticated:
            return redirect('dashboard')

        form=self.form_class(None)
        return render(request,self.template_name,{'form':form})

    def post(self,request):
        if request.user.is_authenticated:
            return redirect('dashboard')

        form=self.form_class(request.POST)
        if form.is_valid():
            user=form.save(commit=False)
            full_name=form.cleaned_data['full_name']
            last_name=form.cleaned_data['last_name']
            email=form.cleaned_data['email']
            password=form.cleaned_data['password']
            user.is_admin=True
            user.set_password(form.cleaned_data['password'])
            user.save()
         
            user=authenticate(email=email,password=password)
            if user is not None:
                login(request,user)
                return redirect('dashboard')
        return render(request,self.template_name,{'form':form})
# end signup


# def login_track(request):
#     act_help.add_logs(request.user.pk,"",4,"Login",request.META['PATH_INFO'],request_helper.get_client_ip(request))
#     return redirect('dashboard')
def login_user(request):
    #logout(request)
    #username = password = ''
    if request.POST:
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                return redirect('dashboard')
    return render_to_response('accounts/login.html', context_instance=RequestContext(request))


def do_logout(request):
    act_help.add_logs(request.user.pk,"",4,"Logout",request.META['PATH_INFO'],request_helper.get_client_ip(request))
    logout(request)
    return redirect('login')

def email_send(email):
    key=sentOTP(email)
    current_time= timezone.now()
    EmailOTP(email=email,otp=key,otp_sent_time=current_time).save()
    last_hour_date_time = current_time-timedelta(hours = 1)
    email_otp_obj=EmailOTP.objects.filter(email=email).order_by('-otp_sent_time')[:1]
    otp_time_hours=email_otp_obj[0].otp_sent_time
    # print(otp_time_hours,last_hour_date_time)
    # exit()
    if otp_time_hours<=last_hour_date_time:
        otp=sentOTP(email)
        EmailOTP.objects.filter(email=email).update(otp=key,otp_sent_time=current_time)
    else:
        otp=email_otp_obj[0].otp
    subject="logon authentication"
    message="Email varification otp "+"/"+str(otp)
    from_email="tiwaryvikash118@gmail.com"
    to_list=[email]

    send_mail(subject,message,from_email,to_list,fail_silently=True)


def sentOTP(email):
    if email:
        key=random.randint(999,9999)
        return key
    else:
        return False